'''
Program 4: Write a Program to Print following Pattern
1 1 1 1
1 1 1 1
1 1 1 1
1 1 1 1
'''

for var1 in range(4) :
    for var2 in range(4) :
        print("1",end= " ")
    print()
