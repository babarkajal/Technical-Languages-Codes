
#take radius from user
radius = int(input("Enter radius: "))

#calculate area
area = 3.14 * radius *radius

print("Area of circle: ", area)

