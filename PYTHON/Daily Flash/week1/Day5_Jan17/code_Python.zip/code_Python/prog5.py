# print ascii value 

ch = input("Enter character: ")

print("ASCII of " ,ch , " : ", ord(ch))
