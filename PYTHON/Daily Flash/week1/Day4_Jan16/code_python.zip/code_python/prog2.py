
priAmt = int(input("Enter the primary ammount: "));
rate = int(input("Enter the interest  rate: "));
year = int(input("Enter the year: "));
	
simpleInterest = priAmt*year* (rate / 100);
print("Simple interest = ", simpleInterest);
