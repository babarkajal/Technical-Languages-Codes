# print first 50 odd num
num =1;
for x in range(50):
    print(num, end = " ")
    num +=2
print()
