
for x in range(10):
    print(x+1, end = " ")
print()
