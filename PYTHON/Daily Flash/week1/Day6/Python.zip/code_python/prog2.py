
sum = 0;
for x in range(10):
    sum += x+1;

print("Sum of first 10 natural num: ",sum)
