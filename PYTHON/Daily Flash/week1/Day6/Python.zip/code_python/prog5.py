
row = int(input("Enetr row: "))
for x in range(row):
    for y in range(row):
        print(" 0 ", end="")
    print()



