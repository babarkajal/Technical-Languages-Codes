# print first 50 even num
num =2;
for x in range(50):
    print(num, end = " ")
    num +=2
print()
