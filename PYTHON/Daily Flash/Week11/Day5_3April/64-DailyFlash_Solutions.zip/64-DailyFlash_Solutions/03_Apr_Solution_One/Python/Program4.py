
freq=float(input("Enter the Frequency :"))

length = (4*(3.142*3.142)*(freq*freq))/9.81
print("Length  :",round(length,4))
