'''
Program 1: Write a Program that coverts entered angle in degree to radians.
Input: In degree: 180
Output: In Radians: 3.412
'''

angle= int(input("Enter angle in degree: "))

print('Angle in radian: ', angle*(3.142/180))
