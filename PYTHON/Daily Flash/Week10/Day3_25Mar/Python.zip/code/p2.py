'''
Program 2: Write a Program that accepts a String from user and prints the
length of that string.
Input: HELLO WORLD
Output: Length of entered string is 11
'''


string = input('Enter string: ')

print('Length of the entered string: ',  len(string))
