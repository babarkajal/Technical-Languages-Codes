'''
Program 2: Write a Program that accepts a String from user in UPPERCASE.
Print that string in lowercase.
Input: HELLO WORLD
Output: hello world
'''


string = input('Enter string: ')

print('String  in lower case: ',  string.lower())
