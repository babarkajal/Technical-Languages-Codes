
import numpy as np

values = np.array([1,2,3,4,5,6,7,8,9],'i')

print(values)
