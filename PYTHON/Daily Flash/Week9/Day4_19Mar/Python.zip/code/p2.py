'''
Program 2: Write a Program that accepts a String (i.e. Array of Characters)
from user. In addition, print that String
Input: Hello from Core2Web
Output: Hello from Core2Web
'''


#accept the input string
string = input('Enter a input string: ')
print('Entered string',string)
