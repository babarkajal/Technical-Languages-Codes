'''
Program 3: Write a Program to find radius of a circle if user provides
circumference of that same circle.
Input: Circumference of circle: 251.36
Output: The Radius of the circle is: 40
'''

cir = float(input("Enter circumference of the circle: "))

print("The radius: ", cir//(2*3.142))
