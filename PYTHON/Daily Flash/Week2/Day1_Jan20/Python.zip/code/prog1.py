
num = int(input("Enter integer value: "))

print("Entered num : " + str(num))
