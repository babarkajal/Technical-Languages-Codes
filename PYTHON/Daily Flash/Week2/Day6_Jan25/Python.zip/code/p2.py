
num1 = int(input("Enter num1: "))
num2 = int(input("Enter num2: ") )

print("Before swapping")
print(num1 ," ",num2)
temp = num1
num1 = num2
num2 = temp
print("After swapping")
print(num1 ," ",num2)

