
num1 = int(input("Enter num: "))




for i in range(num1):
    var = i+1    
    if( i %2 == 0): 
        print("Cube of ", var , ": ",  var*var*var , "  ", "sqaure of ", var, ": ", var*var )


