
num1 = int(input("Enter num1: "))
num2 = int(input("Enter num2: ") )

if num1 > num2:
    print(num1 , " is greater")
else:
    print(num2 , " is greater")

