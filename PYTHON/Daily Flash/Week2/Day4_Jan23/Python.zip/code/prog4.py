
row = int(input("Enetr row num: "))


for olc in range(row):
        for ilc in range(olc+1):
            print("*" , end= " ")
        print()
