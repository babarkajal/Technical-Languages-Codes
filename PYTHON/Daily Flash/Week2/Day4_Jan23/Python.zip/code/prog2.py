
row = int(input("Enetr row num: "))

var =1;
for olc in range(row):
        for ilc in range(olc+1):
            print(var , end= " ")
            var +=1
        print()
