'''
Program 3: Write a Program to print table of 2.
Output: 2 4 6 8 10 12 14 16 18 20
'''
print("Table of 2");
for x in range(10):
        print( (x+1)*2 , end ="  ")
print()
