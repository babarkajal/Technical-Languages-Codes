#take two num 
num1 = int(input("Enter num 1: "))
num2 = int(input("Enter num 2: "))


print("Multiplication: " , num1*num2)
if num1 > num2:
    print("Division: " , num1/num2)
else:
    print("Division: " , num2/num1)
        
