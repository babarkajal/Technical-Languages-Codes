
num1 = int(input("Enter num 1: "))
num2 = int(input("Enter num 2: "))


print("Addition: " , num1+num2)
if num1 > num2:
    print("Substraction: " , num1-num2)
else:
    print("Substraction: " , num2-num1)
        
