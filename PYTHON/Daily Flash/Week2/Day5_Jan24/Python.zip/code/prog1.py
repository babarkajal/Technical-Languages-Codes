for lc in range(1,100):
        
        if(lc%3==0 or lc%5==0):
            print(lc ,end = " ")
print()
