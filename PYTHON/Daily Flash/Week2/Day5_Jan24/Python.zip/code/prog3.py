num = int(input("Enter num: "))

for x in range(num):
        y = x+1;
        print("Cube of ", y ,": ", y*y*y , "and Square of " , y ,": ", y*y )
