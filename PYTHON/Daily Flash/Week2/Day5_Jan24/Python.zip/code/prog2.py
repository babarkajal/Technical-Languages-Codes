for lc in range(1,100):
        
        if(lc%4==0 and lc%7==0):
            print(lc ,end = " ")
print()
