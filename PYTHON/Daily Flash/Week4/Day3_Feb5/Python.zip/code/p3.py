
for num in range(1,100+1):
    if num % 2 == 0:
        continue
    else:
        print(num, end = " ")
print()
