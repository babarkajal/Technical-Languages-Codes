
num = int(input("Enter num: "))

print(hex(num))
