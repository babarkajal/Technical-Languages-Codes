'''
Program 2: Write a Program to Convert entered Decimal Number to Octal
Number
Input: Decimal Number: 15
Output: Octal Number: 17
'''

dec = int(input("Enter decimal num: "))

print("Octal= ", oct(dec))
