
st = input("String : ")

print(st[-1::-1] in st)
