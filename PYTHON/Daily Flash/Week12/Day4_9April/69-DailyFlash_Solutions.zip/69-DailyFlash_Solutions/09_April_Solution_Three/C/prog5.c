#include<stdio.h>


int main() {
	printf("%d", 8 * 7 * 6);
}	
