/*
Program 1: Write a program to print First 10 Natural Numbers.
Output: 1 2 3 4 5 6 8 9 10*/


import java.io.*;

class Program {
	public static void main(String[] args) throws IOException {
		for(int i=1; i<=10; i++)
			System.out.print(i+" " );		
		System.out.println();
	}
}
