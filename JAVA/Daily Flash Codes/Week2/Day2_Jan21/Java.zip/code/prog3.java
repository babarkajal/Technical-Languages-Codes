/*
 * Program 3: Write a Program to print table of 2.
Output: 2 4 6 8 10 12 14 16 18 20
*/

class Program {
	public static void main(String[] args)  {
		
		System.out.println("Table of 2");	
		for(int num=1; num<=10; num++) 
			System.out.print( (2*num) + "  " );
		System.out.println();	

	}
}
