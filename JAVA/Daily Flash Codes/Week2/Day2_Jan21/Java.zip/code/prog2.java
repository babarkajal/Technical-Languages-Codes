/*Program 2 : Write a Program t o print cu be of first 20 numbers .
Output:
Cube of 1: 1
Cube of 2: 8
Cube of 3: 27
.
.
.
Cube of 20: 8000
*
*/

class Program {
	public static void main(String[] args)  {
		for(int i=1; i<=20; i++)
			System.out.println("Cube of " + i + ": " + (i*i*i));
	}


}
